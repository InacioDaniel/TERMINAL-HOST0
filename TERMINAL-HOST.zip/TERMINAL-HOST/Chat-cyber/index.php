<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,1,0" />
    <link rel="stylesheet" href="./css/style.css">

    <title>Chat | TERMINAL HOST</title>
</head>
<body>
    
    <section class="container">

        <section class="login">
            <h2>SEJA LIVRE - ESCOLHA OUTRO NOME</h2>
            <form class="login__form">
                <input type="text" class="login__input" placeholder="Seu nome" required />
                <button type="submit" class="login__button">Entrar</button>
            </form>
        </section>

        <section class="chat">
            <section class="chat__messages">
               <div class="message--self">WELCOME TO!</div>

                <div class="message--other">
                    <span class="message--sender">TERMINAL-HOST</span>
                    SEJA BEM VINDO(A).
                </div> 
            </section>

            <form class="chat__form">
                <input type="text" class="chat__input" placeholder="Digite uma mensagem. Ex: hello group!!!" required />
                <button type="submit" class="chat__button">
                    <span class="material-symbols-outlined">ENVIAR</span>
                </button>
            </form>
        </section>

    </section>

    <script src="./js/script.js"></script>
</body>
</html>
