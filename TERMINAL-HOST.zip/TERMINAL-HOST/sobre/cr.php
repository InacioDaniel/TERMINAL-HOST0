<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" href="../img/chat.png">
    <link rel="shortcut icon" href="../img/chat.png" type="image/x-icon">
    <title>DEV</title>
    <style>
        .ani{
            font-family: arial;
            font-weight: bolder;
            font-size: 40pt;
            position: fixed; 
            left: 15%;
            animation: js 14s infinite;
        }

        @keyframes js{
           from {
             top: -10%;
         }
           to {
             top: 90%;
        } 
}
    </style>
</head>
<body background="../chat-cyber/images/background2.png" text="white"><br><br><br>
<center>
<div class="ani">
<h1>Desenvolvedores</h1>
    @INACIO.U.DANIEL <br><br>
</div>
</center>

</body>
</html>