<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" href="../img/chat.png">
    <link rel="shortcut icon" href="../img/chat.png" type="image/x-icon">
    <title>Sobre</title>
    <style>
        .btn-ver{
            border: 2px solid transparent;
            border-radius: 90px;
            font-size: 07pt;
            padding: 15px;
            background: grey;
            color: #ffffff;
            text-shadow: 02px 02px 02px blue;
        }
        .btn-ver:hover{
            background: #f0f0f0;
        }
        .btn-ver:focus{
            background: black;
        }
        .btn-ver:active{
            background: blue;
        }
        p{
            font-family: arial;
            font-size: 15pt;
            color: white;
            text-shadow: 02px 02px 02px BLUE;
            text-align: justify;
        }
    </style>
</head>
<body background="../chat-cyber/images/background2.png" text="white"><br><br><center>

<a href="cr.php"><button class="btn-ver"><h1>Desenvolvedores....</h1></button></a></center>
<br>
<h1 align="center" style="font-family: arial;">SOBRE O <B><I>TERMINAL HOST</I></B></h1>
<p>O Terminal Host é uma PLATAFORMA de codigo aberto, criado pela comunidade TERMINAL HOST, que foi criada no <font style="text-shadow: 02px 02px 02px LIGHTGREEN; color: white;">WHATSAPP</font> por @inacio.u.daniel que ao longo do tempo foi ganhando novos Administradores. A ideia de uma comunidade online fora da rede social <font style="text-shadow: 02px 02px 02px LIGHTGREEN; color: white;">WHATSAPP</font>, foi desencadeada por H@RO e outros membros da comunidade. Daí surgiu a ideia de começar a trabalhar no projecto que foi de imediato lançada na github para que podesse ser trabalhada por todos desenvolvedores da comunidade. Criou-se então um novo grupo na comunidade, grupo esse encarregue de tratar dos assuntos do projecto. No grupo faziam parte apenas aqueles que estivessem interessados de forma direta ou indireta de ajudar no desenvolvimento da mesma.</p>

<p>Alguns dias passaram e @inacio.u.daniel perdeu a comunicação com o grupo, apesar disso continuou a trabalhar no desenvolvimento da plataforma, sem ter nenhuma comunicação com a comunidade do <font style="text-shadow: 02px 02px 02px LIGHTGREEN; color: white;">WHATSAPP</font>. Os primeiros códigos do Terminal host foram consedidos pelo H@URO que começou a trabalhar com a línguagem de marcação html e a línguagem javascript usando a framework nodejs. Quando chegou a mão de @inacio.u.daniel o código foi alterado para que podesse ser trabalhado em PHP, Javascript, nodejs e html5, e ainda a framework bootstrap, que foi pouco usada, trazendo uma nova dinamica ao código da plataforma, pois essa implementação de várias línguagens e frameworks melhorou o desempenho e ainda complementou o TERMINAl-HOST. Essa variedade permitirá a melhoria continua do TERMINAL-HOST de forma mais prática.</p>

<p>O <i><b>O TERMINAL-HOST,</b></i> apesar de simples, exigiu muito trabalho, e só foi possivel graças ao Trabalho coletivo da comunidade, terminal Host. o mesmo continuará ser melhorado e vai receber atualizações bem como novas funções.</p>
</body>
</html>